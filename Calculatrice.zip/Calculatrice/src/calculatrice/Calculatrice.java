

package calculatrice;

public class Calculatrice 
{
    public static void main(String[] args) 
    {
        Graphique G=new Graphique();
    }
}


